"""
Face landmarks -> per-frame numbers (EAR, MAR, head pose ratios).

One consistent definition used by data collection, training AND live inference.
Only numbers are produced - no image is ever stored (SmartCap spec section 14).
"""
import math
import os
import time
from pathlib import Path

import numpy as np

# MediaPipe face-mesh indices
LEFT_EYE = [33, 160, 158, 133, 153, 144]     # corner, top1, top2, corner, bottom2, bottom1
RIGHT_EYE = [362, 385, 387, 263, 373, 380]
MOUTH_CORNERS = (61, 291)
MOUTH_PAIRS = ((13, 14), (82, 87), (312, 317))   # inner-lip top/bottom pairs (vertical opening)
NOSE, FOREHEAD, CHIN = 1, 10, 152
OUTER_L, OUTER_R = 33, 263

ROW_FIELDS = ["t_s", "face", "ear", "ear_l", "ear_r", "mar", "yaw", "pitch", "roll",
              "face_w", "brightness"]

DEFAULT_MODEL = Path(__file__).resolve().parents[1] / "models" / "face_landmarker.task"


def _xy(lm, i, w, h):
    return (lm[i].x * w, lm[i].y * h)


def _d(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def eye_aspect_ratio(lm, idx, w, h):
    p = [_xy(lm, i, w, h) for i in idx]
    horizontal = _d(p[0], p[3])
    if horizontal <= 1e-6:
        return 0.0
    return (_d(p[1], p[5]) + _d(p[2], p[4])) / (2.0 * horizontal)


def mouth_aspect_ratio(lm, w, h):
    width = _d(_xy(lm, MOUTH_CORNERS[0], w, h), _xy(lm, MOUTH_CORNERS[1], w, h))
    if width <= 1e-6:
        return 0.0
    opens = [_d(_xy(lm, a, w, h), _xy(lm, b, w, h)) for a, b in MOUTH_PAIRS]
    return sum(opens) / (len(opens) * width)


def head_pose_ratios(lm, w, h):
    """Cheap head pose from 2D landmarks (no camera calibration needed).

    yaw   : nose offset from the eye midpoint / eye distance, clipped to [-1, 1] (0 = facing camera)
    pitch : nose position between forehead (0) and chin (1); changes when the head tilts up/down
    roll  : tilt of the line between the outer eye corners, degrees
    face_w: eye-corner distance as a fraction of the frame width (small = far away)
    """
    xa, ya = _xy(lm, OUTER_L, w, h)
    xb, yb = _xy(lm, OUTER_R, w, h)
    span = xb - xa
    if abs(span) <= 1e-6:
        return 0.0, 0.5, 0.0, 0.0
    mid_x = (xa + xb) / 2.0
    yaw = max(-1.0, min(1.0, (lm[NOSE].x * w - mid_x) / span))
    top, bottom = lm[FOREHEAD].y * h, lm[CHIN].y * h
    pitch = (lm[NOSE].y * h - top) / (bottom - top) if abs(bottom - top) > 1e-6 else 0.5
    roll = math.degrees(math.atan2(yb - ya, xb - xa))
    return yaw, pitch, roll, abs(span) / w


def features_from_landmarks(lm, w, h):
    ear_l = eye_aspect_ratio(lm, LEFT_EYE, w, h)
    ear_r = eye_aspect_ratio(lm, RIGHT_EYE, w, h)
    yaw, pitch, roll, face_w = head_pose_ratios(lm, w, h)
    return {"face": 1, "ear": (ear_l + ear_r) / 2.0, "ear_l": ear_l, "ear_r": ear_r,
            "mar": mouth_aspect_ratio(lm, w, h), "yaw": yaw, "pitch": pitch, "roll": roll,
            "face_w": face_w}


def no_face_row():
    nan = float("nan")
    return {"face": 0, "ear": nan, "ear_l": nan, "ear_r": nan, "mar": nan, "yaw": nan,
            "pitch": nan, "roll": nan, "face_w": nan}


def open_camera(index=0, width=640, height=480):
    import cv2
    # DirectShow is Windows-only; on Linux / Raspberry Pi use the default backend (V4L2).
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW) if os.name == "nt" else cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open camera {index}. Close other apps using it or try --camera 1.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    return cap


class FaceFeatureExtractor:
    """MediaPipe Face Landmarker (pretrained) wrapped to return one feature row per frame."""

    def __init__(self, model_path=DEFAULT_MODEL):
        import mediapipe as mp
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision as mp_vision

        model_path = Path(model_path)
        if not model_path.exists():
            raise FileNotFoundError(f"Face Landmarker model not found: {model_path}")
        self._mp = mp
        options = mp_vision.FaceLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_path=str(model_path)),
            running_mode=mp_vision.RunningMode.VIDEO,
            num_faces=1,
            min_face_detection_confidence=0.5,
            min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5,
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=False,
        )
        self._landmarker = mp_vision.FaceLandmarker.create_from_options(options)
        self._t0 = time.perf_counter()
        self._last_ms = -1

    def process(self, frame_bgr):
        import cv2
        t_s = time.perf_counter() - self._t0
        h, w = frame_bgr.shape[:2]
        rgb = np.ascontiguousarray(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        ts_ms = max(int(t_s * 1000), self._last_ms + 1)      # must strictly increase
        self._last_ms = ts_ms
        result = self._landmarker.detect_for_video(image, ts_ms)
        row = {"t_s": t_s, "brightness": float(frame_bgr.mean())}
        if result.face_landmarks:
            row.update(features_from_landmarks(result.face_landmarks[0], w, h))
        else:
            row.update(no_face_row())
        return row

    def close(self):
        try:
            self._landmarker.close()
        except Exception:
            pass
